#include <iostream>
#include <thread>
#include <chrono>

using namespace std;
// Thiis is it.
//# AgeWoorks...

class TrafficLight {
public:
    void run() {
        while (true) {
            switch (currentState) {
                case State::RED:
                    cout << "RED\n";
                    this_thread::sleep_for(chrono::seconds(10));
                    currentState = State::GREEN;
                    break;
                case State::GREEN:
                    cout << "GREEN\n";
                    this_thread::sleep_for(chrono::seconds(10));
                    currentState = State::YELLOW;
                    break;
                case State::YELLOW:
                    cout << "YELLOW\n";
                    this_thread::sleep_for(chrono::seconds(4));
                    currentState = State::RED;
                    break;
            }
        }
    }

private:
    enum class State { RED, GREEN, YELLOW };
    State currentState = State::RED;
};

int main() {
    cout << "==================TRAFFIC MANAGEMENT SYSTEM==================\n";
   


    TrafficLight trafficLight;
    thread lightThread(&TrafficLight::run, &trafficLight);
    lightThread.join();

    return 0;
}
  //This is it.
  //# AgeWorks...
